<?php
session_start();
include_once 'php/connect.php';
if (!isset($_SESSION['unique_id'])) {
	
	header("location:login.php");

	
}

?>

<?php
include_once 'header.php';
?>
<body>
	
	<div class="wrapper">
		<section class="chat-area">
			<header>
				<?php
                    $user_id = $_GET['user_id'];
		           $sql = mysqli_query($conn,"SELECT * FROM `user_info` WHERE `unique_id`='$user_id'");
					if (mysqli_num_rows($sql)>0) {  
						$ftch = mysqli_fetch_assoc($sql);
						

						}  
                  ?>

				<a href="user.php" class="back-icon"><i class="fa fa-arrow-left"></i></a>
				<img src="adminimage/<?=$ftch['image'] ?>" alt="" style="object-fit:cover">
					<div class="details">
						<span><?php echo $ftch['fname'] ." ". $ftch['lname'] ?></span>
						<p><?=$ftch['status']?></p>
					</div>
					<div class="header-icon">
						<a href="#" class="phone"><i class="fa fa-phone"></i></a>
						<a href="#" class="video"><i class="fa fa-video-camera"></i></a>
						<a href="#" class="info"><i class="fa fa-info-circle"></i></a>
					</div>
			</header>
			<div class="chat-box">
				
				
			</div>
			<form  class="typing-area">
			    <button data-tooltip="Attach File"><i class="fa fa-paperclip"></i></button>
				<button data-tooltip="Attach photo/video"><i class="fa fa-photo"></i></button>
				<button data-tooltip="record voice"><i class="fa fa-microphone"></i></button>
				<input type="hidden" name="outgoing_id" type="text" value="<?php echo  $_SESSION['unique_id'] ?>" name="">
				<input type="hidden" name="incoming_id" type="text" value="<?php echo  $user_id ?>" name="">
				<input type="text" class="input_field" name="message" placeholder="Type here..." id="emoji" >
				<button class="send_msg"><i class="fa fa-paper-plane"></i></button>
			</form>	
		</section>
	</div>

<script type="text/javascript" src="javascript/chat.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/emojionearea/3.4.2/emojionearea.min.js" integrity="sha512-hkvXFLlESjeYENO4CNi69z3A1puvONQV5Uh+G4TUDayZxSLyic5Kba9hhuiNLbHqdnKNMk2PxXKm0v7KDnWkYA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
	
	<script type="text/javascript">
		$('#emoji').emojioneArea({
			pickerPosition: "top",
			toneStyle: "bullet",
			filterPosition: "bottom"
		});
	</script>

</body>
</html>