<?php  include("header.php")   ?>

<div class="col col-lg-12">
    <img src="doc2.jpg" class="img img-responsive" alt="">
</div>
<br clear="all">
<br>
<br>

<div class="col col-lg-12 mainbox" style="background-color:white;padding:10px">
    <center>
    <div class="col col-lg-4 box">
        <h2>Patients</h2>
        <h4>Register & Book Appointment</h4>
        <a href="patient_login.php"> Click Here</a>
    </div>

    <div class="col col-lg-4 box1">
        <h2>Doctors Login</h2>
        <a href="doctor_login.php"> Click Here</a>
    </div>

    <div class="col col-lg-4 box1">
        <h2>Admin Login</h2>
        <a href="admin_login.php"> Click Here</a>
    </div>
    </center>
</div>
<?php  include("footer.php")   ?>