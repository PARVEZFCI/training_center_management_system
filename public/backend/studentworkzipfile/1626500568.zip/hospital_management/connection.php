<?php

$servername="localhost";
$username="root";
$password="";
$databasename="hospital";

$conn=mysqli_connect($servername,$username,$password,$databasename);

?>