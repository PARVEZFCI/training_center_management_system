<?php  include("header.php")   ?>


<br>
<br>

<div class="col col-lg-12 mainbox" style="background-color:white;padding:10px">
<div class="col col-lg-1"></div>
<div class="col col-lg-4 box">
   <h3> <b> Contact Form </b> </h3>
   <form action="">
   <input type="text" placeholder="Enter Your Name" class="form-control"><br>
   <input type="text" placeholder="Enter Your Email" class="form-control"> <br>
   
   <textarea name="" id=""  rows="5" class="form-control"></textarea> <br>

   <input type="submit" value="SEND" class="pull-right btn btn-success">
   </form>


    </div>
    <div class="col col-lg-2"></div>

    <div class="col col-lg-4 box">
    <h2 style="font-size: 30px;font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;color:green;">TUSHAR'S DENTAL CARE<sup>+</sup></h2>
<p>South Mojlishpur, Feni Sadar, Bangladesh</p>
<br>

<p>tushar@dental.com</p>
+88 01979-679113
<br><br>

    </div>
    
</div>
<?php  include("footer.php")   ?>