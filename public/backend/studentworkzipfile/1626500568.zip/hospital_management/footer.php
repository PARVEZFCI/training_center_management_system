

<div class="col col-lg-12"><br><br><br></div>

<div class="col col-lg-12" style="font-family:tahoma;box-shadow:1px 1px 4px #dcdcdc;padding:20px;background:#fff" >
<h2 style="font-size: 30px;font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;color:green;">TUSHAR'S DENTAL CARE<sup>+</sup></h2>
<p>South Mojlishpur, Feni Sadar, Bangladesh</p>
<br>

<p>tushar@dental.com</p>
+88 01979-679113
<br><br>

<p class="icon">

<span class="fa fa-instagram"></span> 
<span class="fa fa-whatsapp"></span>
<span class="fa fa-facebook"></span>
<span class="fa fa-youtube"></span>
<span class="fa fa-twitter"></span>
</p>



    
</div>


<div class="col col-lg-12" style="font-family:tahoma;box-shadow:1px 1px 4px #dcdcdc;padding:20px;background:#fff;letter-spacing:1px" >
<center>&copy; 2021 <a href="#">TUSHAR'S DENTAL CARE</a> . All rights reserved</center>
</div>








</div>
</div>
